from textblob import TextBlob
import pandas as pd

# Load the full dataset (replace the file name with yours)
df = pd.read_csv("amazon_reviews.csv", low_memory=False)
# Print all column names to see what's available
print(df.columns)

# Load the original dataset
df = pd.read_csv("amazon_reviews.csv", low_memory=False)

# Keep only the useful columns
df_small = df[['reviews.text', 'reviews.rating', 'reviews.date']]

# Remove any rows with missing values
df_small.dropna(inplace=True)

# Rename columns for easier use
df_small.columns = ['review_text', 'rating', 'review_date']

# Save the cleaned dataset
df_small.to_csv("clean_reviews.csv", index=False)

print("Cleaned file saved as 'clean_reviews.csv'")

# Load the original dataset (make sure it's in the same folder)
df = pd.read_csv("amazon_reviews.csv", low_memory=False)

# Keep only the useful columns
df_small = df[['reviews.text', 'reviews.rating', 'reviews.date']]

# Remove any rows with missing values
df_small.dropna(inplace=True)

# Rename columns for easier use
df_small.columns = ['review_text', 'rating', 'review_date']

# Save the cleaned dataset
df_small.to_csv("clean_data.csv", index=False)
print("Cleaned file saved as 'clean_data.csv'")

# Load the cleaned dataset
df = pd.read_csv("clean_reviews.csv")

# Function to analyze sentiment


def analyze_sentiment(text):
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity
    if polarity > 0.1:
        return "Positive"
    elif polarity < -0.1:
        return "Negative"
    else:
        return "Neutral"


# Apply the function to the review_text column
df['sentiment'] = df['review_text'].apply(analyze_sentiment)
# Save the result to a new file
df.to_csv("reviews_with_sentiment.csv", index=False)
print("Sentiment analysis complete. File saved as 'reviews_with_sentiment.csv'")
